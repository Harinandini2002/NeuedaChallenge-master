package com.neuedatraining.CreditCardApplication.exception;

public class CardUserAlreadyFoundException  extends Exception{
    public CardUserAlreadyFoundException(String message) {
        super(message);
    }
}
